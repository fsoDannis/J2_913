package com.dinkydetails.weatherpull;

import android.content.Context;

public class DataStorage {

	public static void storeStringFile(Context baseContext, String string,
			String string2) {
		// TODO Auto-generated method stub
		
	}


}
