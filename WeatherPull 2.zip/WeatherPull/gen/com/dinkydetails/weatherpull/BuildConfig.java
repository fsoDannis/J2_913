/** Automatically generated file. DO NOT MODIFY */
package com.dinkydetails.weatherpull;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}